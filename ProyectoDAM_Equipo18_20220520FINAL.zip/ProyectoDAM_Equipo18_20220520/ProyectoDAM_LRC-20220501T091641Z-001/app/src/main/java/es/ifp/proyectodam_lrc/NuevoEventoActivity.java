package es.ifp.proyectodam_lrc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class NuevoEventoActivity extends AppCompatActivity {
    protected TextView label1;
    protected Button boton1;
    protected Button boton2;
    protected EditText texto1;
    protected EditText texto2;
    protected EditText texto3;
    protected DataBaseSQL db;
    protected Intent pasarPantalla;
    protected String contenidoCaja1="";
    protected String contenidoCaja2="";
    protected String contenidoCaja3="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_evento);
        label1=(TextView) findViewById(R.id.label1_evento);
        boton1 =(Button) findViewById(R.id.boton1_evento);
        boton2 =(Button) findViewById(R.id.boton2_evento);
        texto1 =(EditText) findViewById(R.id.texto1_evento);
        texto2 =(EditText) findViewById(R.id.texto2_evento);
        texto3 =(EditText) findViewById(R.id.texto3_evento);



        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db = new DataBaseSQL(NuevoEventoActivity.this);
                contenidoCaja1 = texto3.getText().toString();
                contenidoCaja2 = texto2.getText().toString();
                contenidoCaja3 = texto1.getText().toString();
                db.insertInvitado(contenidoCaja1, contenidoCaja2, contenidoCaja3);
                Toast.makeText(NuevoEventoActivity.this, "Añadido correctamente", Toast.LENGTH_LONG).show();
                pasarPantalla = new Intent(NuevoEventoActivity.this, Conteo2Activity.class);
                finish();
                startActivity(pasarPantalla);

            }
        });
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pasarPantalla = new Intent(NuevoEventoActivity.this, ListadoActivity.class);
                finish();
                startActivity(pasarPantalla);

            }
        });
    }
}
package es.ifp.proyectodam_lrc;

import android.os.Parcelable;

import java.io.Serializable;

public class Pojo implements Serializable {
    private String lista, invitado, encargada;
    private int id;

    public Pojo(String lista, String invitado, String encargada, int id) {
        this.lista = lista;
        this.invitado = invitado;
        this.encargada = encargada;
        this.id = id;

    }

    public String getLista() {
        return lista;
    }

    public void setLista(String lista) {
        this.lista = lista;
    }

    public String getInvitado() {
        return invitado;
    }

    public void setInvitado(String invitado) {
        this.invitado = invitado;
    }

    public String getEncargada() {
        return encargada;
    }

    public void setEncargada(String encargada) {
        this.encargada = encargada;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

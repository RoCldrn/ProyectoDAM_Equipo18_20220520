package es.ifp.proyectodam_lrc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Conteo2Activity extends AppCompatActivity {
    private Pojo pojo;
    protected TextView label1;
    protected TextView label2;
    protected TextView label3;
    protected Button boton1;
    protected Button boton2;
    protected Button boton3;
    protected Intent pasarPantalla;
    protected Bundle extras;
    protected String paquete1 = "";
    protected DataBaseSQL db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conteo2);

        label1 = (TextView) findViewById(R.id.label1_conteo2);
        label2 = (TextView) findViewById(R.id.label2_conteo2);
        label3 = (TextView) findViewById(R.id.label3_conteo2);
        boton1 = (Button) findViewById(R.id.boton1_conteo2);
        boton2 = (Button) findViewById(R.id.boton2_conteo2);
        boton3 = (Button) findViewById(R.id.boton3_conteo2);
        db = new DataBaseSQL(this);

        contadorInvitados();
        extras = getIntent().getExtras();
        if (extras != null) {
            paquete1 = extras.getString("lista");

            label3.setText(paquete1);

        }

            boton1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    pasarPantalla = new Intent(Conteo2Activity.this, NuevoInvitadoActivity.class);
                    finish();
                    startActivity(pasarPantalla);
                }
            });
            boton2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    pasarPantalla = new Intent(Conteo2Activity.this, ListadoActivity.class);
                    finish();
                    startActivity(pasarPantalla);
                }
            });

        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Conteo2Activity.this);
                builder.setTitle("¿Quieres borrar todos los invitados y crear un nuevo evento?");
                builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        db.deleteAllListas();
                        Toast.makeText(Conteo2Activity.this,"Invitados borrados correctamente", Toast.LENGTH_SHORT).show();
                        pasarPantalla = new Intent(Conteo2Activity.this, NuevoEventoActivity.class);
                        finish();
                        startActivity(pasarPantalla);
                    }
                });
                builder.setNegativeButton("No", null);
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        }
        public void contadorInvitados () {


            int contadorInvitados = new DataBaseSQL(this).contador();
            label2.setText(contadorInvitados + " invitados");

        }
    }

package es.ifp.proyectodam_lrc;

public class Lista {
    protected int id;
    protected String nombre_lista;

    public Lista(int id, String nombre_lista){
        this.id=id;
        this.nombre_lista = nombre_lista;

    }
    public void setId(int id){

    }
    public int getId()
    {
        return this.id;
    }
    public void setNombre_lista(String nombre_lista){
    }
    public String getNombre_lista()
    {
        return this.nombre_lista;
    }
}

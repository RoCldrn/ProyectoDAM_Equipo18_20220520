package es.ifp.proyectodam_lrc;

public class Detalle {
    protected int id;
    protected String nombre_lista;
    protected String nombre_invitado;
    protected String encargada;

    public Detalle(int id, String nombre_lista, String nombre_invitado, String encargada){
        this.id=id;
        this.nombre_lista = nombre_lista;
        this.nombre_invitado = nombre_invitado;
        this.encargada = encargada;
    }

    public void setId(int id){

    }
    public int getId()
    {
        return this.id;
    }
    public void setNombre_lista(String nombre_lista){

    }
    public String getNombre_lista()
    {
        return this.nombre_lista;
    }
    public void setNombre_invitado(String nombre_invitado){

    }
    public String getNombre_invitado()
    {
        return this.nombre_invitado;
    }
    public void setEncargada(String encargada){

    }
    public String getEncargada()
    {
        return this.encargada;
    }


}

package es.ifp.proyectodam_lrc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class RegistroActivity extends AppCompatActivity {
    protected TextView label1_registro;
    protected Button boton1_registro;
    protected Button boton2_registro;
    protected EditText texto1_registro;
    protected EditText texto2_registro;
    protected String contenidoCaja1="";
    protected String contenidoCaja2="";
    protected DataBaseSQL db;
    protected GestorBDAcceso db2;
    protected Intent pasarPantalla;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        label1_registro = (TextView) findViewById(R.id.label1_registro);
        boton1_registro = (Button) findViewById(R.id.boton1_registro);
        boton2_registro = (Button) findViewById(R.id.boton2_registro);
        texto1_registro = (EditText)findViewById(R.id.texto1_registro);
        texto2_registro = (EditText) findViewById(R.id.texto2_registro);

        boton1_registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contenidoCaja1 = texto1_registro.getText().toString();
                contenidoCaja2 = texto2_registro.getText().toString();
                db = new DataBaseSQL(RegistroActivity.this);
                db2.insertPersonal(contenidoCaja1, contenidoCaja2);
                Toast.makeText(RegistroActivity.this, "Guardado correctamente", Toast.LENGTH_LONG).show();
                pasarPantalla = new Intent(RegistroActivity.this, StartActivity.class);
                finish();
                startActivity(pasarPantalla);

            }
        });
        boton2_registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pasarPantalla = new Intent(RegistroActivity.this, AccesoActivity.class);
                finish();
                startActivity(pasarPantalla);
            }
        });



    }
}
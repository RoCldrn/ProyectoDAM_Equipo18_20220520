package es.ifp.proyectodam_lrc.adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

import es.ifp.proyectodam_lrc.DetalleActivity;
import es.ifp.proyectodam_lrc.ListadoActivity;
import es.ifp.proyectodam_lrc.Pojo;
import es.ifp.proyectodam_lrc.R;
import es.ifp.proyectodam_lrc.storage.StorageClass;


public class AdapterPojo extends ArrayAdapter<Pojo> implements View.OnClickListener {

    private ArrayList<Pojo> dataSet;
    Context mContext;

    // View lookup cache
    private static class ViewHolder {
        TextView txtName;
        TextView txtType;
        TextView txtVersion;
        LinearLayout layout;

    }

    public AdapterPojo(ArrayList<Pojo> data, Context context) {
        super(context, R.layout.pojoitemrow, data);
        this.dataSet = data;
        this.mContext = context;

    }

    @Override
    public void onClick(View v) {

        try {

            int position = (Integer) v.getTag();
            Pojo object = getItem(position);
            Intent intent = new Intent(mContext, DetalleActivity.class);

            intent.putExtra("myAwesomePojo", object);

            mContext.startActivity(intent);
        } catch (Exception e) {
            Log.d("paco", e.toString());
        }

    }

    private int lastPosition = -1;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Pojo dataModel = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        ViewHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if (convertView == null) {

            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.pojoitemrow, parent, false);
            viewHolder.txtName = (TextView) convertView.findViewById(R.id.my_invite);
            viewHolder.txtType = (TextView) convertView.findViewById(R.id.my_lists);
            viewHolder.txtVersion = (TextView) convertView.findViewById(R.id.my_boss);
            viewHolder.layout = (LinearLayout) convertView.findViewById(R.id.layout);
            viewHolder.layout.setTag(position);


            result = convertView;

            convertView.setTag(position);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result = convertView;
        }


        lastPosition = position;
        viewHolder.layout.setOnClickListener(this);
        viewHolder.txtName.setText(dataModel.getInvitado());
        viewHolder.txtType.setText(dataModel.getLista());
        viewHolder.txtVersion.setText(dataModel.getEncargada());

        // Return the completed view to render on screen
        return convertView;
    }
}
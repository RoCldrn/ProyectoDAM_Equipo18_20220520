package es.ifp.proyectodam_lrc.storage;

import es.ifp.proyectodam_lrc.Pojo;

public class StorageClass {
    public static Pojo pojo;
}

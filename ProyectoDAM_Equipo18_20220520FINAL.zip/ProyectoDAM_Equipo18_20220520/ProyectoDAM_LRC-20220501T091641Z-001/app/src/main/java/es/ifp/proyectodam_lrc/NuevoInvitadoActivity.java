package es.ifp.proyectodam_lrc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class NuevoInvitadoActivity extends AppCompatActivity {
    protected TextView label1;
    protected TextView label2;
    protected EditText texto1;
    protected EditText texto2;
    protected EditText texto3;
    protected Button boton1;
    protected Button boton2;
    protected String contenidoCaja1="";
    protected String contenidoCaja2="";
    protected String contenidoCaja3="";
    protected DataBaseSQL db;
    protected Intent pasarPantalla;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_invitado);

        label1 = (TextView) findViewById(R.id.label1_nueva);
        texto1 = (EditText) findViewById(R.id.texto1_nueva);
        texto2 = (EditText) findViewById(R.id.texto2_nueva);
        texto3 = (EditText) findViewById(R.id.texto3_nueva);
        boton1 = (Button) findViewById(R.id.boton1_nueva);
        boton2 = (Button) findViewById(R.id.boton2_nueva);


        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contenidoCaja1 = texto1.getText().toString();
                contenidoCaja2 = texto2.getText().toString();
                contenidoCaja3 = texto3.getText().toString();
                if(contenidoCaja1.equals("") ){
                    Toast.makeText(NuevoInvitadoActivity.this, "Debe rellenar todos los campos", Toast.LENGTH_LONG).show();

                }
                else if (contenidoCaja2.equals("")){
                    Toast.makeText(NuevoInvitadoActivity.this, "Debe rellenar todos los campos", Toast.LENGTH_LONG).show();
                }
                else {
                    db = new DataBaseSQL(NuevoInvitadoActivity.this);
                    db.insertInvitado(contenidoCaja1, contenidoCaja2, contenidoCaja3);
                    Toast.makeText(NuevoInvitadoActivity.this, "Añadido correctamente", Toast.LENGTH_LONG).show();
                    pasarPantalla = new Intent(NuevoInvitadoActivity.this, Conteo2Activity.class);
                    finish();
                    startActivity(pasarPantalla);

                }


            }
        });
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pasarPantalla = new Intent(NuevoInvitadoActivity.this, ListadoActivity.class);
                finish();
                startActivity(pasarPantalla);
            }
        });


    }
}
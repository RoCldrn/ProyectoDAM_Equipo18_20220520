package es.ifp.proyectodam_lrc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import es.ifp.proyectodam_lrc.adapter.AdapterPojo;
import es.ifp.proyectodam_lrc.storage.StorageClass;

public class ListadoActivity extends AppCompatActivity {

    protected TextView label1_listado;
    protected Button boton1_listado;
    protected Button boton2_listado;
    protected ListView lista1_listado;
    protected DataBaseSQL db;
    protected Intent pasarPantalla;
    private ArrayList<Pojo> laLista;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado);

        db = new DataBaseSQL(this);
        label1_listado = (TextView) findViewById(R.id.label1_listado);
        boton1_listado = (Button) findViewById(R.id.boton1_listado);
        boton2_listado = (Button) findViewById(R.id.boton2_listado);
        lista1_listado = (ListView) findViewById(R.id.lista1_listado);

        laLista = db.getAll2();
        lista1_listado.setAdapter(new AdapterPojo(laLista, this));

        boton1_listado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pasarPantalla = new Intent(ListadoActivity.this, NuevoEventoActivity.class);
                finish();
                startActivity(pasarPantalla);
            }
        });
        boton2_listado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });


    }
}
package es.ifp.proyectodam_lrc;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class GestorBDAcceso extends SQLiteOpenHelper {
    protected SQLiteDatabase db2;
    public GestorBDAcceso(Context context) {
        super(context, "verificaciones", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db2) {
        db2.execSQL("CREATE TABLE verificaciones (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, usuario TEXT, password TEXT)");
        db2.execSQL("INSERT INTO verificaciones (usuario, password) VALUES ('RoCalCon', '1234')");
        db2.execSQL("INSERT INTO verificaciones (usuario, password) VALUES ('LorePuePa', '5678')");
        db2.execSQL("INSERT INTO verificaciones (usuario, password) VALUES ('CrisYaMur', '9101')");


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db2.execSQL("DROP TABLE IF EXISTS verificaciones");

    }
    public boolean acceso(String usuario, String contraseña) {
        Cursor res = null;
        db2=this.getReadableDatabase();
        res = db2.rawQuery( "SELECT EXISTS (SELECT * FROM verificaciones WHERE usuario = '"+ usuario +"' and password = '"+contraseña+"')", null);

        res.moveToFirst();
        if (res.getInt(0) == 1) {
            res.close();
            return true;
        } else {
            res.close();
            return false;

        }
    }
    public void insertPersonal(String usuario, String contraseña) {
        db2=this.getWritableDatabase();
        db2.execSQL("INSERT INTO verificaciones (usuario, password) VALUES (' "+usuario+" ', '" + contraseña +"')");
        db2.close();
    }
    public void deleteAllPersonal(){
        db2=this.getWritableDatabase();
        db2.execSQL("DELETE FROM verificaciones");
    }
}

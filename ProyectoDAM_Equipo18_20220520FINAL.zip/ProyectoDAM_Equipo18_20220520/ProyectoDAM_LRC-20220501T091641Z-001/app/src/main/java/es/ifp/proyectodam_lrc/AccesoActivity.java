package es.ifp.proyectodam_lrc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AccesoActivity extends AppCompatActivity {
    protected TextView label_acceso1;
    protected EditText editText_acceso1;
    protected EditText editText_acceso2;
    protected Button boton_acceso1;
    protected Button boton_acceso2;
    protected Button boton_acceso3;
    protected String contenidoCaja1="";
    protected String contenidoCaja2="";
    protected GestorBDAcceso db2;
    protected Intent pasarPantalla;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acceso);
        label_acceso1 = (TextView) findViewById(R.id.label_acceso1);
        editText_acceso1 = (EditText) findViewById(R.id.editText_acceso1);
        editText_acceso2 = (EditText) findViewById(R.id.editText_acceso2);
        boton_acceso1 = (Button) findViewById(R.id.boton_acceso1);
        boton_acceso2=(Button) findViewById(R.id.boton_acceso2);
        boton_acceso3=(Button) findViewById(R.id.boton_acceso3);

        boton_acceso1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contenidoCaja1 = editText_acceso1.getText().toString();
                contenidoCaja2 = editText_acceso2.getText().toString();

                    db2 = new GestorBDAcceso(AccesoActivity.this);
                    if (db2.acceso(contenidoCaja1, contenidoCaja2))
                    {

                        Toast.makeText(AccesoActivity.this, "Credenciales correctas", Toast.LENGTH_LONG).show();
                        pasarPantalla = new Intent(AccesoActivity.this, ListadoActivity.class);
                        finish();
                        startActivity(pasarPantalla);
                    }
                    else {
                        Toast.makeText(AccesoActivity.this, "Credenciales erróneas", Toast.LENGTH_LONG).show();
                        pasarPantalla = new Intent(AccesoActivity.this, StartActivity.class);
                        finish();
                        startActivity(pasarPantalla);
                    }


            }
        });
        boton_acceso2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pasarPantalla = new Intent(AccesoActivity.this, RegistroActivity.class);
                finish();
                startActivity(pasarPantalla);

            }
        });
        boton_acceso3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pasarPantalla = new Intent(AccesoActivity.this, StartActivity.class);
                finish();
                startActivity(pasarPantalla);

            }
        });
    }

}
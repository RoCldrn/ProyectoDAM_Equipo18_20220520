package es.ifp.proyectodam_lrc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class StartActivity extends AppCompatActivity {

    protected TextView label1;
    protected ImageView imagen1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        label1 = (TextView) findViewById(R.id.label1_start);
        imagen1 = (ImageView) findViewById(R.id.imagen1_start);

        TimerTask myTimerTask = new TimerTask() {
            @Override
            public void run() {

                Intent pasarPantalla = new Intent(StartActivity.this, AccesoActivity.class);
                finish();
                startActivity(pasarPantalla);
            }
        };
// new timer
        Timer timer = new Timer();
// schedule timer
        timer.schedule(myTimerTask, 3000);
    }
}

package es.ifp.proyectodam_lrc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class DetalleActivity extends AppCompatActivity {
    private Pojo pojo;
    protected TextView label1;
    protected TextView label3;
    protected TextView label4;
    protected TextView label5;
    protected Button boton1;
    protected Button boton2;
    protected Bundle extras;
    protected Intent pasarPantalla;
    private ArrayList<Pojo> laLista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);
        label1 = (TextView) findViewById(R.id.label1_detalle);
        label3 = (TextView) findViewById(R.id.label3_detalle);
        label4 = (TextView) findViewById(R.id.label4_detalle);
        label5 = (TextView) findViewById(R.id.label5_detalle);
        boton1 = (Button) findViewById(R.id.boton1_detalle);
        boton2 = (Button) findViewById(R.id.boton2_detalle);

        //db = new DataBaseSQL(this);


        extras = getIntent().getExtras();
        if (extras != null) {
            /*paquete1 = extras.getString("lista");
            paquete2 = extras.getString("invitado");
            paquete3 = extras.getString("encargada");*/
            try{
                pojo=(Pojo)extras.getSerializable("myAwesomePojo");
                label3.setText(pojo.getLista());
                label4.setText(pojo.getInvitado());
                label5.setText(pojo.getEncargada());
            }catch (Exception e){
                Log.d("paco",e.toString());
            }




        }
        else{
            Toast.makeText(DetalleActivity.this, "No se han recibido paquetes", Toast.LENGTH_SHORT).show();
        }



        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    pasarPantalla = new Intent(DetalleActivity.this, ListadoActivity.class);
                    finish();
                    startActivity(pasarPantalla);
            }
        });
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pasarPantalla = new Intent(DetalleActivity.this, Conteo2Activity.class);
                pasarPantalla.putExtra("lista",label3.getText());
                pasarPantalla.putExtra("id",label3.getText());

                finish();
                startActivity(pasarPantalla);
            }
        });

    }

}
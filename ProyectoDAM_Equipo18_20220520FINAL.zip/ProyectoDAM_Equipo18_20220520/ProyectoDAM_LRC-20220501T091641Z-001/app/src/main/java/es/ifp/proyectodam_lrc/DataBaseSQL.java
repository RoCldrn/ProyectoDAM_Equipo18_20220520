package es.ifp.proyectodam_lrc;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DataBaseSQL extends SQLiteOpenHelper {
    protected SQLiteDatabase db;

    public DataBaseSQL(Context context) {
        super(context, "invitados", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE listas (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, lista TEXT, invitado TEXT, encargada TEXT)");
        /*db.execSQL("INSERT INTO listas (lista, invitado, encargada) VALUES ('Boda Arturo','Arturo López', 'Lorena')");
        db.execSQL("INSERT INTO listas (lista, invitado, encargada) VALUES ('Boda Arturo','María García', 'Lorena')");
        db.execSQL("INSERT INTO listas (lista, invitado, encargada) VALUES ('Evento Influencer', 'Dulceida', 'Cristina')");
        db.execSQL("INSERT INTO listas (lista, invitado, encargada) VALUES ('Evento Influencer', 'María Pombo', 'Cristina')");
        db.execSQL("INSERT INTO listas (lista, invitado, encargada) VALUES ('Comunión Pablo', 'Carla Ruíz', 'Rocío')");
        db.execSQL("INSERT INTO listas (lista, invitado, encargada) VALUES ('Comunión Pablo', 'Lucas Martínez', 'Rocío')");*/

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        db.execSQL("DROP TABLE IF EXISTS listas");

    }

    @SuppressLint("Range")
    public Lista getLista (int id){
        Lista n = null;
        Cursor res = null;
        String contenido = "";
        if (numberOfListas()>0){
            db=this.getReadableDatabase();
            res = db.rawQuery("SELECT distinct lista FROM listas where id=" +id, null);
            res.moveToFirst();

            while(res.isAfterLast() == false){
                n = new Lista(res.getInt(res.getColumnIndex("id")), res.getString(res.getColumnIndex("lista")));
                res.moveToNext();
            }
        }

        return n;
    }
    @SuppressLint("Range")
    public Detalle getDetalleLista (int id){
        Detalle s = null;
        Cursor res = null;
        String contenido = "";
        if (numberOfListas()>0){
            db=this.getReadableDatabase();
            res = db.rawQuery("SELECT * FROM listas where id=" +id, null);
            res.moveToFirst();

            while(res.isAfterLast() == false){
                s = new Detalle(res.getInt(res.getColumnIndex("id")), res.getString(res.getColumnIndex("lista")),res.getString(res.getColumnIndex("invitado")), res.getString(res.getColumnIndex("encargada")));
                res.moveToNext();
            }
        }

        return s;
    }

    public void insertInvitado(String lista, String invitado, String encargada) {
        db=this.getWritableDatabase();
        db.execSQL("INSERT INTO listas (lista, invitado, encargada) VALUES (' "+lista+" ', '" + invitado +"', '" + encargada +"' )");
        db.close();
    }


    @SuppressLint("Range")
    public ArrayList<String> getAllLista(){
        ArrayList<String> filas= new ArrayList<String>();
        Cursor res = null;
        String contenido = "";
        if (numberOfListas()>0){
            db= this.getReadableDatabase();
            res = db.rawQuery("SELECT DISTINCT lista FROM listas", null);
            res.moveToFirst();
            while (res.isAfterLast()==false){
                contenido = res.getString(res.getColumnIndex("lista"));
                filas.add(contenido);
                res.moveToNext();
            }
        }
        return filas;


    }
    @SuppressLint("Range")
    public ArrayList<String> getAll(){
        ArrayList<String> filas= new ArrayList<String>();
        Cursor res = null;
        String contenido = "";
        if (numberOfListas()>0){
            db= this.getReadableDatabase();
            res = db.rawQuery("SELECT * FROM listas", null);
            res.moveToFirst();
            while (res.isAfterLast()==false){
                contenido = res.getInt(res.getColumnIndex("id")) + ".-" + res.getString(res.getColumnIndex("lista"))+ ".-" + res.getString(res.getColumnIndex("invitado"))+ ".-" + res.getString(res.getColumnIndex("encargada"));
                filas.add(contenido);
                res.moveToNext();
            }
        }
        return filas;


    }
    @SuppressLint("Range")
    public ArrayList<Pojo> getAll2(){
        ArrayList<Pojo> filas= new ArrayList<Pojo>();
        Cursor res = null;
        String contenido = "";
        if (numberOfListas()>0){
            db= this.getReadableDatabase();
            res = db.rawQuery("SELECT * FROM listas", null);
            res.moveToFirst();
            while (res.isAfterLast()==false){
                String encargada, invitado, lista;
                int id;
                encargada = res.getString(res.getColumnIndex("encargada"));
                invitado = res.getString(res.getColumnIndex("invitado"));
                lista = res.getString(res.getColumnIndex("lista"));
                id = res.getInt(res.getColumnIndex("id"));
                filas.add(new Pojo(lista, encargada, invitado, id));
                res.moveToNext();
            }
        }
        return filas;


    }
    public int numberOfListas(){
        int num=0;
        db=this.getReadableDatabase();
        num=(int) DatabaseUtils.queryNumEntries(db, "listas");
        db.close();
        return num;

    }
    public void deleteAllListas(){
        db=this.getWritableDatabase();
        db.execSQL("DELETE FROM listas");
    }



    public int contador() {
        db=this.getWritableDatabase();
        //int resultado = db.rawQuery("SELECT * FROM listas where lista='" +lista +"'", null).getCount();
        int resultado = db.rawQuery("SELECT * FROM listas", null).getCount();
        db.close();
        return resultado;
    }
}





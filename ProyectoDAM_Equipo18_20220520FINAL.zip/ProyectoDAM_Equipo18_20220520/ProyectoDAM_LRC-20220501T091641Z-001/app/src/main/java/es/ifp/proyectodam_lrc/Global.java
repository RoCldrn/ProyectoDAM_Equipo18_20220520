package es.ifp.proyectodam_lrc;
public class Global {
    public static String variableGlobal="";
}
